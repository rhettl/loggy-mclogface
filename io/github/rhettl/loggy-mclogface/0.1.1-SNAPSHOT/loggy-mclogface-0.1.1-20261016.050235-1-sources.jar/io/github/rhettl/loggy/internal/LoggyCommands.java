package io.github.rhettl.loggy.internal;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Collections;
import java.util.WeakHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeoutException;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** Permission-gated server commands and isolated report workflow. */
public final class LoggyCommands {
    private static final Logger LOGGER = LoggerFactory.getLogger("Loggy");
    private static final Set<MinecraftServer> ACTIVE = ConcurrentHashMap.newKeySet();
    private static final Set<MinecraftServer> STOPPED = Collections.synchronizedSet(
            Collections.newSetFromMap(new WeakHashMap<>()));
    private static final ExecutorService WORKERS = Executors.newFixedThreadPool(2, task -> {
        Thread thread = new Thread(task, "Loggy report worker");
        thread.setDaemon(true);
        return thread;
    });

    private LoggyCommands() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("loggy").requires(source -> source.method_9259(2))
                .executes(context -> usage(context.getSource()))
                .then(method_9247("list").executes(context -> list(context.getSource())))
                .then(method_9247("report").then(method_9244("target", StringArgumentType.word())
                        .suggests((context, builder) -> class_2172.method_9265(targetIds(), builder))
                        .executes(context -> report(context.getSource(), StringArgumentType.getString(context, "target"))))));
    }

    public static void serverStopping(MinecraftServer server) {
        STOPPED.add(server);
        ACTIVE.remove(server);
    }

    private static List<String> targetIds() {
        List<String> ids = new ArrayList<>();
        ids.add("minecraft");
        LoggyAccess.providers().stream().map(ProviderRegistry.Registration::id).forEach(ids::add);
        ids.add("all");
        return ids;
    }

    private static int usage(class_2168 source) {
        source.method_9226(() -> class_2561.method_43470("Usage: /loggy list | /loggy report <minecraft|target|all>"), false);
        return 1;
    }

    private static int list(class_2168 source) {
        source.method_9226(() -> class_2561.method_43470("Loggy report targets:"), false);
        source.method_9226(() -> class_2561.method_43470("minecraft — Minecraft and environment diagnostics"), false);
        for (ProviderRegistry.Registration provider : LoggyAccess.providers()) {
            source.method_9226(() -> class_2561.method_43470(provider.id() + " — " + provider.displayName() + ": " + provider.description()), false);
        }
        source.method_9226(() -> class_2561.method_43470("all — Minecraft diagnostics and every registered provider"), false);
        return 1;
    }

    private static int report(class_2168 source, String target) {
        MinecraftServer server = source.method_9211();
        if (!target.equals("minecraft") && !target.equals("all")
                && LoggyAccess.providers().stream().noneMatch(provider -> provider.id().equals(target))) {
            source.method_9213(class_2561.method_43470("Unknown Loggy report target: " + target));
            return 0;
        }
        if (!ACTIVE.add(server)) {
            source.method_9213(class_2561.method_43470("A Loggy report is already in progress for this server."));
            return 0;
        }
        if (STOPPED.contains(server)) {
            ACTIVE.remove(server);
            source.method_9213(class_2561.method_43470("This server is stopping; no report was started."));
            return 0;
        }

        ReportCollection collection;
        try {
            collection = ReportCollector.collect(server, target);
        } catch (RuntimeException failure) {
            ACTIVE.remove(server);
            LOGGER.error("Could not collect Loggy report for target {}", target, failure);
            source.method_9213(class_2561.method_43470("Loggy could not collect the report. See the local server log."));
            return 0;
        }
        source.method_9226(() -> class_2561.method_43470("Collecting diagnostics and preparing the report…"), false);
        CompletableFuture.runAsync(() -> prepareAndUpload(server, source, collection), WORKERS)
                .exceptionally(failure -> {
                    LOGGER.error("Loggy report worker failed", failure);
                    complete(server, source, "Loggy report failed before upload. See the local server log.");
                    return null;
                });
        return 1;
    }

    private static void prepareAndUpload(MinecraftServer server, class_2168 source, ReportCollection collection) {
        try {
            CurrentLogSnapshot.Snapshot log = CurrentLogSnapshot.read(server.method_3831(), server.method_3816());
            MclogsGateway.ReportDraft draft = new MclogsGateway.ReportDraft(
                    ReportText.diagnostics(collection, log.available()), log.note(), log.content());
            MclogsGateway.prepare(draft).whenCompleteAsync((lease, preparationFailure) -> {
                try {
                    ReportPersistence.SavedReport saved = null;
                    if (preparationFailure != null) {
                        String fallback = ReportText.fit(draft.diagnostics(), draft.logNote(), draft.log(), 5 * 1024 * 1024, 5_000);
                        fallback = LocalRedactor.redact(fallback);
                        try { saved = ReportPersistence.save(server.method_3831(), collection.collectedAt(), fallback); }
                        catch (Exception saveFailure) { LOGGER.warn("Could not save locally prepared Loggy report", saveFailure); }
                        String location = saved == null ? " Local saving also failed." :
                                " Saved report: " + saved.relativePath().toString().replace('\\', '/');
                        String reason = saved == null ? "Local saving failed and mclo.gs filters or limits could not be verified; upload was skipped."
                                : "Report saved locally; mclo.gs filters or limits could not be verified, so upload was skipped.";
                        complete(server, source, reason + location);
                        return;
                    }

                    try { saved = ReportPersistence.save(server.method_3831(), collection.collectedAt(), lease.content()); }
                    catch (Exception saveFailure) { LOGGER.warn("Could not save prepared Loggy report", saveFailure); }
                    ReportPersistence.SavedReport savedReport = saved;
                    lease.upload().whenCompleteAsync((url, uploadFailure) -> {
                        if (uploadFailure == null) {
                            String path = savedReport == null ? " Local saving failed." :
                                    " Local copy: " + savedReport.relativePath().toString().replace('\\', '/');
                            completeUpload(server, source, url, path);
                        } else {
                            String reason = unwrap(uploadFailure) instanceof TimeoutException ? "The mclo.gs request timed out." :
                                    "mclo.gs could not accept the report.";
                            String path = savedReport == null ? " Local saving also failed." :
                                    " Prepared report saved at " + savedReport.relativePath().toString().replace('\\', '/') + ".";
                            complete(server, source, reason + path);
                        }
                    }, WORKERS).exceptionally(failure -> {
                        LOGGER.error("Loggy upload completion callback failed", failure);
                        complete(server, source, "Loggy upload completion failed. See the local server log.");
                        return null;
                    });
                } catch (RuntimeException callbackFailure) {
                    if (lease != null) lease.close();
                    LOGGER.error("Could not prepare Loggy report persistence", callbackFailure);
                    complete(server, source, "Loggy could not prepare the local report. See the local server log.");
                }
            }, WORKERS).exceptionally(failure -> {
                LOGGER.error("Loggy filter preparation callback failed", failure);
                complete(server, source, "Loggy could not prepare the report. See the local server log.");
                return null;
            });
        } catch (RuntimeException failure) {
            LOGGER.error("Loggy report worker failed", failure);
            complete(server, source, "Loggy report failed before upload. See the local server log.");
        }
    }

    private static Throwable unwrap(Throwable error) {
        while (error.getCause() != null && (error instanceof java.util.concurrent.CompletionException
                || error instanceof java.util.concurrent.ExecutionException)) error = error.getCause();
        return error;
    }

    private static void complete(MinecraftServer server, class_2168 source, String message) {
        dispatch(server, source, () -> class_2561.method_43470(message));
    }

    private static void completeUpload(MinecraftServer server, class_2168 source, String url, String path) {
        dispatch(server, source, () -> class_2561.method_43473()
                .method_10852(class_2561.method_43470("Loggy report uploaded: "))
                .method_10852(class_2561.method_43470(url).method_27694(style -> style
                        .method_10958(new class_2558(class_2558.class_2559.field_11749, url))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Open report")))))
                .method_10852(class_2561.method_43470(" "))
                .method_10852(class_2561.method_43470("[copy]").method_27694(style -> style
                        .method_10958(new class_2558(class_2558.class_2559.field_21462, url))
                        .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Copy report link")))))
                .method_10852(class_2561.method_43470(path)));
    }

    private static void dispatch(MinecraftServer server, class_2168 source,
                                 java.util.function.Supplier<class_2561> message) {
        if (STOPPED.contains(server)) { ACTIVE.remove(server); STOPPED.remove(server); return; }
        try {
            server.execute(() -> {
                try {
                    if (!STOPPED.contains(server)) {
                        if (source != null) source.method_9226(message, false);
                        else LOGGER.info("{}", message.get().getString());
                    }
                } catch (RuntimeException callbackFailure) {
                    LOGGER.debug("Loggy command source was no longer available", callbackFailure);
                } finally {
                    ACTIVE.remove(server);
                    STOPPED.remove(server);
                }
            });
        } catch (RuntimeException serverStopped) {
            ACTIVE.remove(server);
            STOPPED.remove(server);
        }
    }

    /** Isolates internal registry access from the public provider API. */
    private static final class LoggyAccess {
        private static List<ProviderRegistry.Registration> providers() {
            return io.github.rhettl.loggy.api.Loggy.registry().snapshot();
        }
    }
}
