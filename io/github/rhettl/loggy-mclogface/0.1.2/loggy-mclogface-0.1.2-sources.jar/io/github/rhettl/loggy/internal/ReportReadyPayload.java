package io.github.rhettl.loggy.internal;

import io.netty.buffer.ByteBuf;
import java.util.regex.Pattern;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Report completion only; never accepts arbitrary clipboard contents or URL destinations. */
public record ReportReadyPayload(String url) implements class_8710 {
    private static final Pattern SHARE_URL = Pattern.compile("https://mclo\\.gs/[A-Za-z0-9]{1,128}");
    public static final class_9154<ReportReadyPayload> TYPE =
            new class_9154<>(class_2960.method_60655("loggy", "report_ready"));
    public static final class_9139<ByteBuf, ReportReadyPayload> CODEC = class_9139.method_56434(
            class_9135.method_56364(256), ReportReadyPayload::url, ReportReadyPayload::new);

    public ReportReadyPayload {
        if (url == null || !SHARE_URL.matcher(url).matches()) {
            throw new IllegalArgumentException("Invalid mclo.gs report link");
        }
    }

    @Override public class_9154<ReportReadyPayload> method_56479() { return TYPE; }
}
